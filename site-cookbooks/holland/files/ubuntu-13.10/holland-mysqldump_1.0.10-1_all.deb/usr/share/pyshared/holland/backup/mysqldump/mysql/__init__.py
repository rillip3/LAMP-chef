"""MySQL support functions"""

from option import load_options, write_options

__all__ = [
    'load_options',
    'write_options',
]
