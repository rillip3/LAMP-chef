from holland.backup.mysqldump.plugin import MySQLDumpPlugin, CONFIGSPEC

provider = MySQLDumpPlugin
